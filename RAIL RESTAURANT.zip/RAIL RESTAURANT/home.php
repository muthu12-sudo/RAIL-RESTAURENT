﻿
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>Rail Restaurant | Pure Good Delivery | 24/7 Service | Fastest Food Delivery</title>
        <link rel="stylesheet" href="css/style.css" />
        <link rel="icon" href="images/icon.png" type="image/png" />
        

        
    </head>

    <body class="rail">

        <!--Title-->
        <div class="title">
            <img src="images/icon.png" width="70px" height="70px" align="center" alt="logo" />
            <b>RAIL RESTAURANT</b>
        </div>

        <!--navbar-->
        <nav class="nav">
            <ul>
                <li><a href=#home>Home</a></li>
                <li><a href=#foods>Foods</a></li>
                <li><a href=#MenuCard>Menu Card</a></li>
                <li><a href=#party>Party Decoration</a></li>
                <li><a href=#kids>Kids</a></li>
                <li><a href=#medicine>Medicine</a></li>
                <li><a href=#contact>Emergency Help Needer</a></li>
            </ul>
        </nav>
        <h2>Offers For You</h2>
    </body>

    </html>

    </html>